

<?php $__env->startSection('title','pagination'); ?>

<?php $__env->startSection('style'); ?>
    <style>
        .container{
            border: 1px solid black;
        }

    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p>id : <?php echo e($user->id); ?> nom : <?php echo e($user->nom); ?></p>   
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php echo e($users->links('pagination.pagination-link')); ?>



<!-- <div class="recentUserContainer">
    <table class="tableUserContent">
        <p class="tableUserTitle">Utilisateurs récents</p>
        <th class="tableUserHeader">ID</th>
        <th class="tableUserHeader">Nom</th>
        <th class="tableUserHeader">Prénom</th>
        <th class="tableUserHeader">Role</th>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="tableUserligne">
                <td><?php echo e($user->id); ?></td>
                <td><?php echo e($user->nom); ?></td>
                <td><?php echo e($user->prenom); ?></td>
                <td><?php echo e($user->type); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>            
</div> -->





<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Bureau\test\TM4\resources\views/produits/list_paginate.blade.php ENDPATH**/ ?>