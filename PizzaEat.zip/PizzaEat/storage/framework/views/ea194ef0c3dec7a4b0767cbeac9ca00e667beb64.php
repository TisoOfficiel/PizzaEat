

<?php $__env->startSection('linkCSS','/css/menu_vertical.css'); ?>
<?php $__env->startSection('linkCSS1','/css/dashboard/dashboard_nav_bar.css'); ?>
<?php $__env->startSection('linkCSS2','/css/cook/dashboardCommandeCook.css'); ?>


<?php $__env->startSection('content'); ?>

    
<div class="menuContainer">
    <!-- Menu de navigation horizontal -->
    <div>
        <i id="menuicon" class="material-icons" onclick="openNav()"> menu</i>
    </div>

    <!-- Logo -->
    <div>
        <a href="/"><img src="/img/logo_pizza1.png" class="logo"></a>
    </div>
    
   <!-- affichafe personne connecter -->

    <div id="infoUser" class="infoUser" onclick="dropdownmenu()">

        <?php if(Auth::user()->type=='admin'): ?>
            <i id="adminIcon" class="material-icons">verified</i>
        <?php endif; ?>
        <?php if(Auth::user()->type=='cook'): ?>
            <i id="adminIcon" class="material-icons">soup_kitchen</i>
        <?php endif; ?>
        
        <p><?php echo e(Auth::user()->prenom); ?></p>
        <i class="material-icons">expand_more</i>
        <div id="infoUserDropdown" class="infoUserDropdown">
            <div class="infoUserDropdownTitle">
                <p class="infoUserDropdownAuthTitle">Enregistrer comme</p>
                <p class="infoUserDropdownAuth"><?php echo e(Auth::user()-> nom); ?> <?php echo e(Auth::user()-> prenom); ?></p>
            </div>

           <div class="infoUserDropdownContent">
                <a href="/">
                    <div class="infoUserDropdownAccueil">
                        <i class="material-icons">home</i>
                        <p>Accueil</p>
                    </div>
                </a>

                <a href="/<?php echo e(Auth::user()->login); ?>/compteSetting">
                    <div class="infoUserDropdownModifierProfile">
                        <i class="material-icons">edit</i>
                        <p>Modifier son profile</p>
                    </div>
                </a>
           </div>

            <a href="<?php echo e(route('logout')); ?>">
                <div class="infoUserDropdownLogout">
                    <i class="material-icons">logout</i>
                    <p>Se déconnecter</p>
                </div>
            </a>
        </div>
   </div>

</div>

<div class="containersidebar" id ="containersidebar">
    <div id="mySidenav" class="sidenav">
        
        <i class="material-icons" id="closenav" onclick="closeNav()">close</i>

        <div class="profileContainer">
            <div class="profileIcone">
            <i id="personneIcon"class="material-icons">person</i>
        </div>
            
            <div class="profileInfo">
                <p>
                    <?php echo e(Auth::user()->prenom); ?>

                    <?php if(Auth::user()->type=='admin'): ?>
                        <i id="adminIcon" class="material-icons">verified</i>
                    <?php endif; ?>
                    <?php if(Auth::user()->type=='cook'): ?>
                         <i id="adminIcon" class="material-icons">soup_kitchen</i>
                    <?php endif; ?>
                </p>
                <a href="/<?php echo e(Auth::user()->id); ?>/compteSetting">Voir le compte</a>
            </div>
        </div>
                    
        <?php if(Auth::user()->type=='admin'): ?>
            <div class="sidenavdashboard">
                <i class="material-icons">dashboard</i>
                <a href="<?php echo e(route('dashboard')); ?>" class="sidenavlist">Dashboard</a>
            </div>
        <?php endif; ?>
        <?php if(Auth::user()->type=='cook'): ?>
                <div class="sidenavdashboard">
                    <i class="material-icons">dashboard</i>
                    <a href="<?php echo e(route('CookDashboard')); ?>" class="sidenavlist">Dashboard</a>
                </div>
        <?php endif; ?>
        <div class="sidenavCommande">
            <i class="material-icons">bookmark</i>
            <a href="<?php echo e(route('commandeView',['id'=>Auth::user()->id])); ?>" class="sidenavlist">Commandes</a>
        </div>

        <div class="sidenavChangementCompte">
            <i class="material-icons">switch_account</i>
            <a href="#"class="sidenavlist">Changer de compte</a>
        </div>  

        <div class="sidenavdeconnexion">
            <i class="material-icons">logout</i>   
            <a href="<?php echo e(route('logout')); ?>"class="sidenavlist">Déconnexion</a>
        </div>
    </div>
</div>

<div class="commandeUserContainer">
    <div class="commandeUserContent">
        <div>
            <h1>Listes commande</h1>
        </div>
        <div class="commandeUserContentBody">
            <div class="commandeUserContentBodyHeader">

                
            </div>
            
                <table class="tablecontentUserCommande">
                    <thead>
                        <tr class="tablecontentUserCommandeHeader">
                            <th>#UID</th>
                            <th>Nom Prénom</th>
                            <th>#CID</th>
                            <th>Statut</th>
                            <th>Date</th>
                            <th>Total</th>
                            <th>Action</th>
                        </tr>

                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $commandes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $commande): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="tablecontentUserCommandeInfo">
                            <td>#<?php echo e($commande->user_id); ?></td>
                               
                            <td><?php echo e($commande->user->nom); ?> <?php echo e($commande->user->prenom); ?></td>
                            <td>#<?php echo e($commande->id); ?></td>
                            
                            
                            <td class="statutCellule">
                                <div class="statutEnvoye">Envoyé</div>
                                <div class="statutSelect">

                                    
                                    <form action="<?php echo e(route('udpateStatut',['id'=>$commande->id])); ?>" method="post">
                                        <select name="statut" onchange="this.form.submit()" class="select">
                                            <option value="envoye" selected>Envoyé</option>
                                            <option  value="traitement">En traitement</option>
                                            <option value="pret">Prêt</option>
                                            <option value="recupere">Récupéré</option>
                                                                                                        
                                        </select>
                                        <?php echo csrf_field(); ?>
                                            
                                    </form>
                                    <div class="arrowSelectContainer">
                                        <div  class="arrowSelectContent">
                                        <i class="material-icons">expand_more</i>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            
                            
                            
                            <td><?php echo e(date('d.m.Y', strtotime($commande->created_at))); ?></td>
                            <?php $total=0 ?>

                            <?php $__currentLoopData = $commande->pizzas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pizza): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $total += $pizza->prix * $pizza->pivot->qte ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <td><?php echo e($total); ?> €</td>

                            <td><a href="<?php echo e(route('detailCommande',['cid'=>$commande->id,'uid'=>$commande->user_id])); ?>"><button class="tableCommandeDetail">Détails</button></a></td>
                        </tr>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div class="test">
                    <?php echo e($commandes->links('pagination.pagination-linkPizza')); ?>

                </div> 
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Bureau\test\TM4\resources\views/cook/dashboardCommandeCook.blade.php ENDPATH**/ ?>