

<?php if($paginator->hasPages()): ?>   
   <?php if($paginator->onFirstPage()): ?>
        <span class="disable">
            <i class="material-icons">navigate_before</i>
        </span>
        
    <?php else: ?>
        <a href="<?php echo e($paginator->previousPageurl()); ?>" class="previous-link">
            <i class="material-icons">navigate_before</i>
        </a>
        
    <?php endif; ?>
    
   
 
    <?php if($paginator->hasMorePages ()): ?>
        <?php for($i=1;$i<$paginator->lastPage()+1;$i++): ?>
            <?php if($paginator->currentPage()==$i): ?>
            
                <a href="<?php echo e($paginator->url($i)); ?>" class="currentPage"><?php echo e($i); ?></a>
            <?php else: ?> 
                <a href="<?php echo e($paginator->url($i)); ?>"><?php echo e($i); ?></a>
            <?php endif; ?>
        <?php endfor; ?>

        <a href="<?php echo e($paginator->nextPageUrl()); ?>" class="next-link">
            <i class="material-icons">navigate_next</i>
        </a>
        
    <?php else: ?>


       <?php for($i=1;$i<$paginator->lastPage()+1;$i++): ?>
            <?php if($paginator->currentPage()==$i): ?>
            
                <a href="<?php echo e($paginator->url($i)); ?>" class="currentPage"><?php echo e($i); ?></a>
            <?php else: ?> 
                <a href="<?php echo e($paginator->url($i)); ?>"><?php echo e($i); ?></a>
            <?php endif; ?>
        <?php endfor; ?>

        <span class="disable link">
            <i class="material-icons">navigate_next</i>
        </span>
       
    <?php endif; ?>
<?php endif; ?><?php /**PATH D:\Bureau\test\TM4\resources\views/pagination/pagination-linkPizza.blade.php ENDPATH**/ ?>