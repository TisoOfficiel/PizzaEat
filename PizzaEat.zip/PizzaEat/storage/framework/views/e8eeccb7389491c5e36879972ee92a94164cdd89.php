


<?php $__env->startSection('linkCSS','/css/dashboard/dashboard_nav_bar.css'); ?>
<?php $__env->startSection('linkCSS1','/css/menu_vertical.css'); ?>
<?php $__env->startSection('linkCSS3','/css/commandeDetail.css'); ?>

<?php $__env->startSection('content'); ?>


<div class="menuContainer">
    <!-- Menu de navigation horizontal -->
    <div>
        <i id="menuicon" class="material-icons" onclick="openNav()"> menu</i>
    </div>

    <!-- Logo -->
    <div>
        <a href="/"><img src="/img/logo_pizza1.png" class="logo"></a>
    </div>
    
   <!-- affichafe personne connecter -->

    <div id="infoUser" class="infoUser" onclick="dropdownmenu()">
        <?php if(Auth::user()->type=='admin'): ?>
            <i id="adminIcon" class="material-icons">verified</i>
        <?php endif; ?>
        <p><?php echo e(Auth::user()->prenom); ?></p>
        <i class="material-icons">expand_more</i>
        <div id="infoUserDropdown" class="infoUserDropdown">
            <div class="infoUserDropdownTitle">
                <p class="infoUserDropdownAuthTitle">Enregistrer comme</p>
                <p class="infoUserDropdownAuth"><?php echo e(Auth::user()-> nom); ?> <?php echo e(Auth::user()-> prenom); ?></p>
            </div>

           <div class="infoUserDropdownContent">
                <a href="/">
                    <div class="infoUserDropdownAccueil">
                        <i class="material-icons">home</i>
                        <p>Accueil</p>
                    </div>
                </a>

                <a href="<?php echo e(route('UserSettings',['id'=>Auth::user()->id])); ?>">
                    <div class="infoUserDropdownModifierProfile">
                        <i class="material-icons">edit</i>
                        <p>Modifier son profile</p>
                    </div>
                </a>
           </div>

            <a href="<?php echo e(route('logout')); ?>">
                <div class="infoUserDropdownLogout">
                    <i class="material-icons">logout</i>
                    <p>Se déconnecter</p>
                </div>
            </a>
        </div>
   </div>

</div>
<div class="containersidebar" id ="containersidebar">
        <?php if(auth()->guard()->guest()): ?>
        <div id="mySidenav" class="sidenavguest">
            <i class="material-icons" id="closenav" onclick="closeNav()">close</i>
            <a href="<?php echo e(route('login')); ?>" class="loginLink">
                <div class="loginContainer">
                    Se connecter
                </div>
            </a>
            <div class="registerContainer">
                <a href="<?php echo e(route('registerForm')); ?>">Créez un compte</a>
            </div>
                
        <?php endif; ?>


        <?php if(auth()->guard()->check()): ?>
            <div id="mySidenav" class="sidenav">
                <i class="material-icons" id="closenav" onclick="closeNav()">close</i>

                <div class="profileContainer">
                    <div class="profileIcone">
                        <i id="personneIcon"class="material-icons">person</i>
                    </div>
                    <div class="profileInfo">
                        <p>
                            <?php echo e(Auth::user()->prenom); ?>

                            <?php if(Auth::user()->type=='admin'): ?>
                                    <i id="adminIcon" class="material-icons">verified</i>
                            <?php endif; ?>
                        </p>
                        <a href="<?php echo e(route('UserSettings',['id'=>Auth::user()->id])); ?>">Voir le compte</a>
                    </div>

                
                </div>
                
                <?php if(Auth::user()->type=='admin'): ?>
                <div class="sidenavdashboard">
                    <i class="material-icons">dashboard</i>
                    <a href="<?php echo e(route('dashboard')); ?>" class="sidenavlist">Dashboard</a>
                </div>
                <?php endif; ?>
                <div class="sidenavCommande">
                    <i class="material-icons">bookmark</i>
                    <a href="<?php echo e(route('commandeView',['id'=>Auth::user()->id])); ?>" class="sidenavlist">Commandes</a>
                </div>

                <div class="sidenavChangementCompte">
                    <i class="material-icons">switch_account</i>
                    <a href="#"class="sidenavlist">Changer de compte</a>
                </div>  

                <div class="sidenavdeconnexion">
                    <i class="material-icons">logout</i>   
                    <a href="<?php echo e(route('logout')); ?>"class="sidenavlist">Déconnexion</a>
                </div>
        <?php endif; ?>             
                
        </div>
    </div>

<div class="CommandeDetailContainer">
    <div class="CommandeDetailContent">
        <div>
            <h1>Détails de commande </h1>
        </div>
        <div class="CommandeDetailContentBody">
        
            <div class="CommandeDetailContentBodyHeader">
                <div class="headerleft">
                    <div class="headerleftop">
                        <i class="material-icons calendar">calendar_month</i>
                        <h4><?php echo htmlspecialchars_decode(date('j<\s\up>S</\s\up> F Y', strtotime($commande->created_at))); ?></h4>
                    </div>
                    <div class="headerlefbottom">
                        <p>Commande ID : #<?php echo e($commande->id); ?></p>   
                    </div>
                </div>
                <div class="headerright">

                </div>
            </div>
            <div class="separation"></div>
            
            <div class="CommandeDetailContentOrderInfo">

                <div class="CommandeCustomerInfo">
                    <div class="CommandeDetailContentOrderInfoIcon">
                        <div class="iconContainer">
                            <i class="material-icons">person</i>
                        </div>
                    </div>

                    <div class="CommandeDetailContentOrderInfoContent">
                        <h4>Client</h4>
                        <p>Nom: <?php echo e($user->nom); ?></p>
                        <p>Prénom: <?php echo e($user->prenom); ?></p>
                        <p>ID : #<?php echo e($user->id); ?></p>
                        
                        <!-- <a href="" class="userprofile">Voir profile</a> -->
                    </div>
                </div>

                <div class="CommandeOrderinfo">
                    <div class="CommandeDetailContentOrderInfoIcon">
                        <div class="iconContainer">
                            <i class="material-icons">local_shipping</i>
                        </div>
                    </div>
                    <div class="CommandeDetailContentOrderInfoContent">
                        <h4>Info Commande</h4>
                        <p>Expédition: Pizza Eat</p>
                        <p>Moyen de paiement</p>
                        <p>Statut : <?php echo e($commande->statut); ?></p>
                    </div>
                </div>

                <div class="CommandeAdresseInfo">
                    <div class="CommandeDetailContentOrderInfoIcon">
                        <div class="iconContainer">
                            <i class="material-icons">location_on</i>
                        </div>
                    </div>
                    <div class="CommandeDetailContentOrderInfoContent">
                        <h4>Livrer à </h4>
                        <p>Ville : Créteil</p>
                        <p>Numéro Rue : 61 </p>
                        <p>Adresse: Av. du Général de Gaulle </p>
                    </div>
                </div>

            </div>

            <div class="DetailCommandeContent">
                <div class="tableRecapContainer">
                    <table>
                        <thead>
                            <tr class="listPizza">

                                <th>Pizza</th>
                                <th>Prix unitaire</th>
                                <th>Quantité</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <?php $TotalCommande = 0 ?>
                        <tbody>
                        <?php $__currentLoopData = $commande->pizzas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pizza): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $total=0 ?>
                            <tr class="listPizza">   
                                <td><?php echo e($pizza->nom); ?></td>
                                
                                
                                <td><?php echo e($pizza->prix); ?> €</td>
                                <td><?php echo e($pizza->pivot->qte); ?></td>
                                <?php $total+= $pizza->prix * $pizza->pivot->qte?>
                                <?php $TotalCommande += $total ?>
                                <td><?php echo e($total); ?> €</td>
                            </tr>
                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td colspan="4">
                                    <article class="float-end">
                                    <dl class="dlist">
                                        <dt>SubTotal: </dt>
                                        <dd><?php echo e($TotalCommande); ?> €</dd>
                                    </dl>
                                    <dl class="dlist">
                                        <dt>Frais de livraison: </dt>
                                        <dd>Gratuit</dd>
                                        </dl>
                                    <dl class="dlist">
                                        <dt>Total: </dt>
                                        <dd style="font-weight:bold;font-size:24px"><?php echo e($TotalCommande); ?> €</dd>
                                        </dl>
                                    <dl class="dlist">
                                        <dt class="statut">Statut:</dt>
                                        <dd class="paiementstatut">
                                            <div>Paiement fait </div>
                                        </dd>
                                    </dl>
                                    </article>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <div class="PaiementInfoCard">
                    <h4>Info de paiement </h4>
                    <div class="card">
                        <img src="/img/mastercard.png" alt="" class="mastercard">
                        <p>Master Card **** **** 1234</p>
                    </div>
                    <p> Business name: Grand Market LLC</p>
                    <p>Phone: +1 (800) 555-154-52</p>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Bureau\test\TM4\resources\views/commandeDetails.blade.php ENDPATH**/ ?>