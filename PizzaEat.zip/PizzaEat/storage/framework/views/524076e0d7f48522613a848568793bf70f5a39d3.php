

<?php $__env->startSection('title','Modification Pizza'); ?>


<?php $__env->startSection('content'); ?>
    
    <form action="<?php echo e(route('modificationPizza',['id'=>$id])); ?>" method="post">

        <input type="text" name="NewPizzaNom"  value="<?php echo e(old('NomPizza')); ?>">
        <input type="text" name="NewPizzaDescription"value="<?php echo e(old('DescriptionPizza')); ?>">
        <input type="submit" value ="Modifier">

        <?php echo csrf_field(); ?>

    </form>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Bureau\test\TM4\resources\views/admin/modificationFormulaire.blade.php ENDPATH**/ ?>