
<?php $__env->startSection('title','File upload'); ?>
<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('fupload')); ?>" method="post" enctype="multipart/form-data">
<input type="file" name="fichier">
<input type="submit" value="Téléverser">
<?php echo csrf_field(); ?>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Bureau\test\TM4\resources\views/upload/form.blade.php ENDPATH**/ ?>