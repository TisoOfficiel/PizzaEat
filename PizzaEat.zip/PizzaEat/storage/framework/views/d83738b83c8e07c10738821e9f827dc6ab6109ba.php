
<?php if($paginator->hasPages()): ?>
   <?php if($paginator->onFirstPage()): ?>
        <span class="disable">
            <i class="material-icons">navigate_before</i>
        </span>
    <?php else: ?>
        <a href="<?php echo e($paginator->previousPageurl()); ?>" class="previous-link">
            <i class="material-icons">navigate_before</i>
        </a>
    <?php endif; ?>
    <?php if($paginator->hasMorePages ()): ?>
       <a href="<?php echo e($paginator->nextPageUrl()); ?>" class="next-link">
            <i class="material-icons">navigate_next</i>
        </a>
    <?php else: ?>
        <span class="disable link">
            <i class="material-icons">navigate_next</i>
        </span>
   <?php endif; ?>
<?php endif; ?><?php /**PATH D:\Bureau\test\TM4\resources\views/pagination/pagination-link.blade.php ENDPATH**/ ?>