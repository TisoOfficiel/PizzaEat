

<?php $__env->startSection('linkCSS','/css/dashboard/dashboardUser.css'); ?>
<?php $__env->startSection('linkCSS1','/css/menu_vertical.css'); ?>
<?php $__env->startSection('linkCSS2','/css/dashboard/dashboard_nav_bar.css'); ?>
<?php $__env->startSection('linkCSS3','/css/dashboard/dashboardNavVertical.css'); ?>

<?php $__env->startSection('content'); ?>


<div class="menuContainer">
    <!-- Menu de navigation horizontal -->
    <div>
        <i id="menuicon" class="material-icons" onclick="openNav()"> menu</i>
    </div>

    <!-- Logo -->
    <div>
        <a href="/"><img src="/img/logo_pizza1.png" class="logo"></a>
    </div>
    
   <!-- affichafe personne connecter -->

    <div id="infoUser" class="infoUser" onclick="dropdownmenu()">
        <i id="adminIcon" class="material-icons">verified</i>
        <p><?php echo e(Auth::user()->prenom); ?></p>
        <i class="material-icons">expand_more</i>
        <div id="infoUserDropdown" class="infoUserDropdown">
            <div class="infoUserDropdownTitle">
                <p class="infoUserDropdownAuthTitle">Enregistrer comme</p>
                <p class="infoUserDropdownAuth"><?php echo e(Auth::user()-> nom); ?> <?php echo e(Auth::user()-> prenom); ?></p>
            </div>

           <div class="infoUserDropdownContent">
                <a href="/">
                    <div class="infoUserDropdownAccueil">
                        <i class="material-icons">home</i>
                        <p>Accueil</p>
                    </div>
                </a>

                <a href="<?php echo e(route('UserSettings',['id'=>Auth::user()->id])); ?>">
                    <div class="infoUserDropdownModifierProfile">
                        <i class="material-icons">edit</i>
                        <p>Modifier son profile</p>
                    </div>
                </a>
           </div>

            <a href="<?php echo e(route('logout')); ?>">
                <div class="infoUserDropdownLogout">
                    <i class="material-icons">logout</i>
                    <p>Se déconnecter</p>
                </div>
            </a>
        </div>
   </div>

</div>

<div class="containersidebar" id ="containersidebar">
    <div id="mySidenav" class="sidenav">
        
        <i class="material-icons" id="closenav" onclick="closeNav()">close</i>

        <div class="profileContainer">
            <div class="profileIcone">
            <i id="personneIcon"class="material-icons">person</i>
        </div>
            
            <div class="profileInfo">
                <p>
                    <?php echo e(Auth::user()->prenom); ?>

                    <?php if(Auth::user()->type=='admin'): ?>
                        <i id="adminIcon" class="material-icons">verified</i>
                    <?php endif; ?>
                </p>
                <a href="/<?php echo e(Auth::user()->id); ?>/compteSetting">Voir le compte</a>
            </div>
        </div>
                    
        <?php if(Auth::user()->type=='admin'): ?>
            <div class="sidenavdashboard">
                <i class="material-icons">dashboard</i>
                <a href="<?php echo e(route('dashboard')); ?>" class="sidenavlist">Dashboard</a>
            </div>
        <?php endif; ?>
        <div class="sidenavCommande">
            <i class="material-icons">bookmark</i>
            <a href="<?php echo e(route('commandeView',['id'=>Auth::user()->id])); ?>" class="sidenavlist">Commandes</a>
        </div>

        <div class="sidenavChangementCompte">
            <i class="material-icons">switch_account</i>
            <a href="#"class="sidenavlist">Changer de compte</a>
        </div>  

        <div class="sidenavdeconnexion">
            <i class="material-icons">logout</i>   
            <a href="<?php echo e(route('logout')); ?>"class="sidenavlist">Déconnexion</a>
        </div>
    </div>
</div>

<div class="dashboardUserListe">
    <div id="dashboardMenu" class="dashboardMenu">
        <div class="dashboardMenuLinkContainer">
            <div class="dashboardMenureduce" onclick="dashboardMenureduce()">
                <div class="dashboardMenureduceIcon" >

                    <i id="dashboardMenureduceIcon"class="material-icons nav_vertical_icon" >menu_open</i>
                </div>
            </div>
            <div class="dashboardMenuContent">
                    
                <a href="<?php echo e(route('dashboard')); ?>">
                    <div class="dashboardMenuLink">
                        <i class="material-icons nav_vertical_icon">dashboard</i>
                        <div class="dashboardMenuLinkText">Dashboard</div>
                    </div>
                </a>
                <a href="<?php echo e(route('commandeListe')); ?>">
                    <div class="dashboardMenuLink">
                        <i class="material-icons nav_vertical_icon">local_shipping</i>
                        <div class="dashboardMenuLinkText">Commandes</div>
                    </div>
                </a>
                <a href="<?php echo e(route('dashboardPizza')); ?>">
                    <div class="dashboardMenuLink ">
                        <i class="material-icons nav_vertical_icon">shopping_bag</i>
                        <div class="dashboardMenuLinkText">Pizzas</div>
                    </div>
                </a>
                <a href="<?php echo e(route('dashboardUser')); ?>">
                    <div class="dashboardMenuLink active">
                        <i class="material-icons nav_vertical_icon">group</i>
                        <div class="dashboardMenuLinkText">Utilisateurs</div>
                    </div>
                </a>
            </div>
        </div>  
    </div>




    <div class="dashboardUserListeContainer">

        <!-- Header -->
        <div class="userlisteHeader">
            <h1 class="userListeHeaderTitle">Liste d'utilisateurs</h1>
        </div>
        <div class="separation"></div>
        <!-- Body -->

        <div class="userListeBodyContainer">
        
            <div class="userListeContainer">
                <div class="userListeContent">


                    <div class="userListeContentHeader">

                        <div class="userListeContentFilter">
                            <?php switch($roleactif):

                                    case ("All"): ?>

                                        <form action="<?php echo e(route('dashboardUserfilter')); ?>" method="post">

                                            <input type="submit" id="Alluserfilter" name="role" value="Voir Tout" class="userListefilter userfilteractif" >
                                            <?php echo csrf_field(); ?>
                                        </form>

                                        <form action="<?php echo e(route('dashboardUserfilter')); ?>" method="post">
                                            <input type="submit" id="userfilter" name="role" value="Utilisateur" class="userListefilter" >
                                            <?php echo csrf_field(); ?>
                                        </form>

                                        <form action="<?php echo e(route('dashboardUserfilter')); ?>" method="post">
                                            <input type="submit" id="cookuserfilter" name="role" value="Cuisinier" class="userListefilter" >
                                            <?php echo csrf_field(); ?>
                                        </form>

                                        <form action="<?php echo e(route('dashboardUserfilter')); ?>" method="post">
                                            <input type="submit" id="adminuserfilter" name="role" value="Admin" class="userListefilter">
                                            <?php echo csrf_field(); ?>
                                        </form>
                                    <?php break; ?>
                                    
                                    <?php case ("user"): ?>
                                        <form action="<?php echo e(route('dashboardUserfilter')); ?>" method="post">
                                            <input type="submit" id="Alluserfilter"  name="role" value="Voir Tout" class="userListefilter " >
                                            <?php echo csrf_field(); ?>
                                        </form>

                                        <form action="<?php echo e(route('dashboardUserfilter')); ?>" method="post">
                                            <input type="submit" id="userfilter" name="role" value="Utilisateur" class="userListefilter userfilteractif" >
                                            <?php echo csrf_field(); ?>
                                        </form>

                                        <form action="<?php echo e(route('dashboardUserfilter')); ?>" method="post">
                                            <input type="submit" id="cookuserfilter" name="role" value="Cuisinier" class="userListefilter" >
                                            <?php echo csrf_field(); ?>
                                        </form>

                                        <form action="<?php echo e(route('dashboardUserfilter')); ?>" method="post">
                                            <input type="submit" id="adminuserfilter" name="role" value="Admin" class="userListefilter">
                                            <?php echo csrf_field(); ?>
                                        </form>
                                    <?php break; ?>

                                    <?php case ("cook"): ?>
                                        <form action="<?php echo e(route('dashboardUserfilter')); ?>" method="post">
                                            <input type="submit" id="Alluserfilter" name="role" value="Voir Tout" class="userListefilter " >
                                            <?php echo csrf_field(); ?>
                                        </form>

                                        <form action="<?php echo e(route('dashboardUserfilter')); ?>" method="post">
                                            <input type="submit" id="userfilter" name="role" value="Utilisateur" class="userListefilter " >
                                            <?php echo csrf_field(); ?>
                                        </form>

                                        <form action="<?php echo e(route('dashboardUserfilter')); ?>" method="post">
                                            <input type="submit" id="cookuserfilter" name="role" value="Cuisinier" class="userListefilter userfilteractif" >
                                            <?php echo csrf_field(); ?>
                                        </form>

                                        <form action="<?php echo e(route('dashboardUserfilter')); ?>" method="post">
                                            <input type="submit" id="adminuserfilter" name="role" value="Admin" class="userListefilter">
                                            <?php echo csrf_field(); ?>
                                        </form>
                                    <?php break; ?>

                                    <?php case ("admin"): ?>
                                    <form action="<?php echo e(route('dashboardUserfilter')); ?>" method="post">
                                            <input type="submit" id="Alluserfilter" name="role" value="Voir Tout" class="userListefilter " >
                                            <?php echo csrf_field(); ?>
                                        </form>

                                        <form action="<?php echo e(route('dashboardUserfilter')); ?>" method="post">
                                            <input type="submit" id="userfilter" name="role" value="Utilisateur" class="userListefilter " >
                                            <?php echo csrf_field(); ?>
                                        </form>

                                        <form action="<?php echo e(route('dashboardUserfilter')); ?>" method="post">
                                            <input type="submit" id="cookuserfilter" name="role" value="Cuisinier" class="userListefilter " >
                                            <?php echo csrf_field(); ?>
                                        </form>

                                        <form action="<?php echo e(route('dashboardUserfilter')); ?>" method="post">
                                            <input type="submit" id="adminuserfilter" name="role" value="Admin" class="userListefilter userfilteractif">
                                            <?php echo csrf_field(); ?>
                                        </form>
                                    <?php break; ?>


                                    <?php default: ?>
                                       
                                        <form action="<?php echo e(route('dashboardUserfilter')); ?>" method="post">
                                            <input type="submit" id="Alluserfilter" name="role" value="Voir Tout" class="userListefilter userfilteractif" >
                                            <?php echo csrf_field(); ?>
                                        </form>

                                        <form action="<?php echo e(route('dashboardUserfilter')); ?>" method="post">
                                            <input type="submit" id="userfilter" name="role" value="Utilisateur" class="userListefilter" >
                                            <?php echo csrf_field(); ?>
                                        </form>

                                        <form action="<?php echo e(route('dashboardUserfilter')); ?>" method="post">
                                            <input type="submit" id="cookuserfilter" name="role" value="Cuisinier" class="userListefilter" >
                                            <?php echo csrf_field(); ?>
                                        </form>

                                        <form action="<?php echo e(route('dashboardUserfilter')); ?>" method="post">
                                            <input type="submit" id="adminuserfilter" name="role" value="Admin" class="userListefilter">
                                            <?php echo csrf_field(); ?>
                                        </form>

                                    <?php break; ?>
                            <?php endswitch; ?>
                            
                        </div>

                        <div class="addUserContainer">
                            <button onclick="openModalAddUser()"class="btnAddmember">Ajouter un membre</button>
                        </div>

                    </div>

                        <div class="userlistContainerBody">

                            <?php $__empty_1 = true; $__currentLoopData = $utilisateurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $utilisateur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="userListContentContainer">
                            
                                    <div class="userListeID">
                                        <p>#<?php echo e($utilisateur->id); ?></p>
                                    </div>
                                    <div class="userListInfo">
                                        <div class="userListeInfoImg"><i class="material-icons">person</i></div>
                                        <div class="userListeInfoNom">
                                            <p><?php echo e($utilisateur->nom); ?> <?php echo e($utilisateur->prenom); ?></p>
                                        </div>
                                    </div>
                                    <div class="userListInfoLogin">
                                        <p>@ <?php echo e($utilisateur->login); ?></p>
                                    </div>
                                    <div class="userListTypeContainer">
                                        <?php switch($utilisateur->type):

                                            case ('user'): ?>
                                            <div class="userListTypeContent userrole">
                                                    <p><?php echo e($utilisateur->type); ?></p>
                                            </div>
                                            <?php break; ?>

                                            <?php case ('cook'): ?>
                                            <div class="userListTypeContent cookrole">
                                                    <p><?php echo e($utilisateur->type); ?></p>
                                            </div>
                                            <?php break; ?>

                                            <?php case ('admin'): ?>
                                            <div class="userListTypeContent adminrole">
                                                    <p><?php echo e($utilisateur->type); ?></p>
                                            </div>
                                            <?php break; ?>
                                        <?php endswitch; ?>
                                    </div>
                                    
                                    <div class="selectContainer">
                                        <div class="selectContent">
                                            <form action="<?php echo e(route('udpateRole',['id'=>$utilisateur->id])); ?>" method="post">
                                                <select name="role" onchange="this.form.submit()" class="select">
                                                    <?php switch($utilisateur->type):
                                                        case ("admin"): ?>
                                                        <option selected value="admin">Admin</option>
                                                        <option value="cook">Cuisinier</option>
                                                        <option value="user">User</option>
                                                        <?php break; ?>
                                                
                                                        <?php case ("cook"): ?>
                                                        <option value="admin">admin</option>
                                                        <option value="cook"selected>Cuisinier</option>
                                                        <option value="user">User</option>
                                                        <?php break; ?>

                                                        <?php case ("user"): ?>
                                                        <option value="admin">admin</option>
                                                        <option value="cook">Cuisinier</option>
                                                        <option value="user" selected>User</option>
                                                        <?php break; ?>
                                                    <?php endswitch; ?>
                                                
                                                </select>
                                            <?php echo csrf_field(); ?>
                                        
                                            </form>
                                            <div class="arrowSelectContainer">
                                                <div  class="arrowSelectContent">
                                                    <i class="material-icons">expand_more</i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                
                                    
                                    <div  id="userListmoreOption" data_id="userListmoreOption"class="userListmoreOption" onclick="opendropdownmenuserliste('<?php echo e($utilisateur->id); ?>')">
                                        <i class="material-icons pizzaListMoreOptionLinkIcon">more_horiz</i>

                                        <div id="<?php echo e($utilisateur->id); ?>" class="userListeDropdown">
                                            
                                            <div class="userlisteDropdownContent">

                                                <a href="<?php echo e(route('editmemberview',['id'=>$utilisateur->id])); ?>">
                                                    <div class="userlisteDropdownContentedit">
                                                        <i class="material-icons">edit</i>
                                                        <p>Modifier</p>
                                                    </div>
                                                </a>

                                                <a href="<?php echo e(route('removemember',['id'=>$utilisateur->id])); ?>" class="remove">
                                                    <div class="userlisteDropdownContentremove">
                                                        <i class="material-icons">delete</i>
                                                        <p>Supprimer</p>
                                                    </div>
                                                </a>
                                            </div>

                                        </div>



                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="NoUserListe">
                                    <p>Il n'y a pas d'utilisateurs</p>
                                </div>
                                <?php for($i=1;$i < 7;$i++): ?>
                                    <div class="userListContentContainer">
                                    
                                        <div class="userListeID">
                                            <p># <?php echo e($i); ?></p>
                                        </div>
                                        <div class="userListInfo">
                                            <div class="userListeInfoImg"><i class="material-icons">person</i></div>
                                            <div class="userListeInfoNom">
                                                <p>NULL</p>
                                            </div>
                                        </div>
                                        <div class="userListInfoLogin">
                                            <p>@ NULL</p>
                                        </div>
                                        <div class="userListTypeContainer">
                                            <p>NULL</p>
                                        </div>
                                    
                                        <div class="selectContainer">
                                            
                                            <p>NULL</p>
                                        
                                        </div>
                                
                                        <div class="pizzaListMoreOption" >
                                        <i class="material-icons pizzaListMoreOptionLinkIcon">more_horiz</i>
                                        </div>
                                    </div>
                                <?php endfor; ?>
                            <?php endif; ?>

                    </div>
                    
                
                
                <div class="test">
                    <?php echo e($utilisateurs->links('pagination.pagination-linkPizza')); ?>

                </div>
            </div>

        </div>


        
    </div>
</div>


<div id="modalUserListe" class="modalUserListe" >
    <div id="containerAddModalUserListe" class="containerAddModalUserListe">
        
        <div class="modalUserListeAddheader">

            <div class="close" onclick="closeModalUserListeadd()">
                <i class="material-icons closeIcon">close</i>
            </div>

        </div>

        <form action="<?php echo e(route('addMember')); ?>" method="POST">
                
            <div class="formContentInfo">
               
                <input id="nom" type="text" name="nom" value="<?php echo e(old('nom')); ?>" placeholder="Nom">
                <input id="prenom" type="text" name="prenom" value="<?php echo e(old('prenom')); ?>" placeholder="Prénom">
                
            </div>

            <div class="formContentInfo">
                
                <input id="login" type="text" name="login" value="<?php echo e(old('login')); ?>" placeholder="Login">
                
                <select name="roleuser" id="roleuser">
                    <option value="user" selected>Utilisateur</option>
                    <option value="cook">Cuisinier</option>
                    <option value="admin">Admin</option>
                </select>
            </div>
                
            <div class="formContent mdp">
               
                <input type="password" name="mdp" id="mdpRegister" placeholder="Mot de passe">
                <i id="passwordNotVisble"class="material-icons passwordNotVisble" onclick="visiblemdpregister()">visibility_off</i>
                
            </div>

            <div class="formContent mdp">
                <input type="password" name="mdp_confirmation" id="mdpRegisterConfirmation" placeholder="Confirmation de mot de passe">
            </div>    
                
            
            <div class="formContentSubmit">
                <input type="submit" value="Créer le membre" class="btn">
            </div>
            <?php echo csrf_field(); ?>
        </form>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Bureau\test\TM4\resources\views/admin/dashboard/utilisateurs.blade.php ENDPATH**/ ?>