

<?php $__env->startSection('title','DashBoard Pizza'); ?>

<?php $__env->startSection('linkCSS','/css/dashboard/dashboardPizza.css'); ?>
<?php $__env->startSection('linkCSS1','/css/menu_vertical.css'); ?>
<?php $__env->startSection('linkCSS2','/css/dashboard/dashboard_nav_bar.css'); ?>
<?php $__env->startSection('linkCSS3','/css/dashboard/dashboardNavVertical.css'); ?>


<?php $__env->startSection('content'); ?>

<div class="menuContainer">
    <!-- Menu de navigation horizontal -->
    <div>
        <i id="menuicon" class="material-icons" onclick="openNav()"> menu</i>
    </div>

    <!-- Logo -->
    <div>
        <a href="/"><img src="/img/logo_pizza1.png" class="logo"></a>
    </div>
    
   <!-- affichafe personne connecter -->

    <div id="infoUser" class="infoUser" onclick="dropdownmenu()">
        <i id="adminIcon" class="material-icons">verified</i>
        <p><?php echo e(Auth::user()->prenom); ?></p>
       <i class="material-icons">expand_more</i>
        <div id="infoUserDropdown" class="infoUserDropdown">
            <div class="infoUserDropdownTitle">
                <p class="infoUserDropdownAuthTitle">Enregistrer comme</p>
                <p class="infoUserDropdownAuth"><?php echo e(Auth::user()-> nom); ?> <?php echo e(Auth::user()-> prenom); ?></p>
            </div>

           <div class="infoUserDropdownContent">
                <a href="/">
                    <div class="infoUserDropdownAccueil">
                        <i class="material-icons">home</i>
                        <p>Accueil</p>
                    </div>
                </a>

                <a href="<?php echo e(route('UserSettings',['id'=>Auth::user()->id])); ?>">
                    <div class="infoUserDropdownModifierProfile">
                        <i class="material-icons">edit</i>
                        <p>Modifier son profile</p>
                    </div>
                </a>
           </div>

            <a href="<?php echo e(route('logout')); ?>">
                <div class="infoUserDropdownLogout">
                    <i class="material-icons">logout</i>
                    <p>Se déconnecter</p>
                </div>
            </a>
        </div>
   </div>

</div>



<div class="containersidebar" id ="containersidebar">
    <div id="mySidenav" class="sidenav">
        
        <i class="material-icons" id="closenav" onclick="closeNav()">close</i>

        <div class="profileContainer">
            <div class="profileIcone">
            <i id="personneIcon"class="material-icons">person</i>
        </div>
            
            <div class="profileInfo">
                <p>
                    <?php echo e(Auth::user()->prenom); ?>

                    <?php if(Auth::user()->type=='admin'): ?>
                        <i id="adminIcon" class="material-icons">verified</i>
                    <?php endif; ?>
                </p>
                <a href="/<?php echo e(Auth::user()->id); ?>/compteSetting">Voir le compte</a>
            </div>
        </div>
                    
        <?php if(Auth::user()->type=='admin'): ?>
            <div class="sidenavdashboard">
                <i class="material-icons">dashboard</i>
                <a href="<?php echo e(route('dashboard')); ?>" class="sidenavlist">Dashboard</a>
            </div>
        <?php endif; ?>
        <div class="sidenavCommande">
            <i class="material-icons">bookmark</i>
            <a href="<?php echo e(route('commandeView',['id'=>Auth::user()->id])); ?>" class="sidenavlist">Commandes</a>
        </div>

        <div class="sidenavChangementCompte">
            <i class="material-icons">switch_account</i>
            <a href="#"class="sidenavlist">Changer de compte</a>
        </div>  

        <div class="sidenavdeconnexion">
            <i class="material-icons">logout</i>   
            <a href="<?php echo e(route('logout')); ?>"class="sidenavlist">Déconnexion</a>
        </div>
    </div>
</div>




<div class="dashboardPizza">

    <div id="dashboardMenu" class="dashboardMenu">
        <div class="dashboardMenuLinkContainer">
            <div class="dashboardMenureduce" onclick="dashboardMenureduce()">
                <div class="dashboardMenureduceIcon" >

                    <i id="dashboardMenureduceIcon"class="material-icons nav_vertical_icon" >menu_open</i>
                </div>
            </div>
            <div class="dashboardMenuContent">
               
                <a href="<?php echo e(route('dashboard')); ?>">
                    <div class="dashboardMenuLink">
                    <i class="material-icons nav_vertical_icon">dashboard</i>
                    <div class="dashboardMenuLinkText">Dashboard</div>
                    </div>
                </a>
                <a href="<?php echo e(route('commandeListe')); ?>">
                    <div class="dashboardMenuLink">
                        <i class="material-icons nav_vertical_icon">local_shipping</i>
                        <div class="dashboardMenuLinkText">Commandes</div>
                    </div>
                </a>
                <a href="<?php echo e(route('dashboardPizza')); ?>">
                    <div class="dashboardMenuLink active">
                        <i class="material-icons nav_vertical_icon">shopping_bag</i>
                        <div class="dashboardMenuLinkText">Pizzas</div>
                    </div>
                </a>
                <a href="<?php echo e(route('dashboardUser')); ?>">
                    <div class="dashboardMenuLink">
                        <i class="material-icons nav_vertical_icon">group</i>
                        <div class="dashboardMenuLinkText">Utilisateurs</div>
                    </div>
                </a>
            </div>
        </div>  
    </div>
    
    <div class="dashboardPizzaContainer">

            <!-- Header -->
            <div class="pizzaHeader">
                <h1 class="pizzaHeaderTitle">Catalogue de pizza</h1>
            </div>
            <div class="separation"></div>
            
            <!-- Body -->
            <div class="pizzaContainer">
                <div class="addPizzaContainer">
                    <button onclick="openModalAddpizza()"class="btnAddPizza">Ajouter une pizza</button>
                    
                        <form action="<?php echo e(route('dashboardPizzaUpdate')); ?>" method="post">
                            <input type="date" name="dateFrom" class="calendarPizza" onchange='this.form.submit()' value="<?php echo e(Request::old('dateFrom')); ?>">
                        <?php echo csrf_field(); ?>
                        </form> 
                </div>
                <div class="pizzaListContainer">
                    <?php $__currentLoopData = $pizzasPaginate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pizza): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="pizzaListItem">
                            <div class="pizzaListInfo">
                                <div class="pizzaListInfoImg"></div>
                                <div class="pizzaListInfoNom">
                                    <p><?php echo e($pizza->nom); ?></p>
                                </div>
                            </div>
                            <div class="pizzaListDescription">
                                <p><?php echo e($pizza->description); ?></p>
                            </div>
                            <div class="pizzaListPrix">
                                <p><?php echo e($pizza->prix); ?> €</p>
                            </div>
                            <div class="pizzaListDate">
                                <p><?php echo e(date('d.m.Y', strtotime($pizza->updated_at))); ?></p>
                            </div>
                            
                            <div class="pizzaListMoreOption" onclick="openModalEditpizza('<?php echo e($pizza->id); ?>','<?php echo e($pizza->nom); ?>','<?php echo e($pizza->description); ?>','<?php echo e($pizza->prix); ?>')">
                                <i class="material-icons pizzaListMoreOptionLinkIcon">edit</i>
                            </div>
                            <a href="<?php echo e(route('removePizza',['id'=>$pizza->id])); ?>" style="text-decoration:none;">
                                <div class="pizzaListMoreOption">
                                    <i class="material-icons pizzaListMoreOptionLinkIcon" style="color:red">delete</i>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </div>

                <div class="test">
                   <?php echo e($pizzasPaginate->links('pagination.pagination-linkPizza')); ?>

                </div>
            </div>
        </div>
</div>

<div id="modalPizza" class="modalPizza" >
    <div id="containerAddModalPizza" class="containerAddModalPizza">
        <div class="modalPizzaAddheader">

            <div class="close" onclick="closeModalpizza()">
                <i class="material-icons closeIcon">close</i>
            </div>
        </div>
        <form action="/admin/dashboard/pizza/add" method="post" class="FormAddModalPizza" enctype="multipart/form-data">

            <div class="formContent">
                <label for="NomPizza">Nom de la pizza</label>
                <input id="NomPizza" type="text" name="NomPizza" placeholder="Margarita" class="inputAddmodalPizza">
            </div>

            <div class="formContent">
                <label for="File">Importer une photo</label>
                <input type="file" name="fichier">
            </div>
               
           
            <div class="formContent">
                <label for="descriptionPizzaAdd">Description de la pizza</label>
                <textarea  id="descriptionPizzaAdd"  name="DescriptionPizza" placeholder="Tomate,fromage et olive" class="inputAddmodalPizza"></textarea>
            </div>

            <div class="formContent">
                <label for="PrixPizza">Prix de la pizza</label>
                <input id="PrixPizza" type="text" name="PrixPizza" placeholder="10" class="inputAddmodalPizza">
            </div>
            
            
            <div class="formContent btndiv">
                <input type="submit" value="Ajouter pizza" class="inputAddmodalPizza btn"> 
            </div>       
            
            <?php echo csrf_field(); ?>
        </form>
    
    </div>

    <div id="containerEditModalPizza" class="containerEditModalPizza">
        <div class="modalPizzaEditheader">


            <div class="close" onclick="closeModalpizza()">
                <i class="material-icons closeIcon">close</i>
            </div>
        </div>
        <form action="" method="post" class="FormEditModalPizza" id="FormEditModalPizza" enctype="multipart/form-data">

            <div class="formContent">
                <label for="NomPizzaEdit">Nom de la pizza</label>
                <input id="NomPizzaEdit" type="text" name="NewPizzaNom" placeholder="Margarita" class="inputAddmodalPizza" >
            </div>
            
            <div class="formContent">
                <label for="File">Importer une photo</label>
                <input type="file" name="Newfichier">
            </div>
           
            <div class="formContent">
                <label for="descriptionPizzEdit">Description de la pizza</label>
                <textarea  id="descriptionPizzEdit"  name="NewPizzaDescription" placeholder="Tomate,fromage et olive" class="inputAddmodalPizza"></textarea>
            </div>

            <div class="formContent">
                <label for="PrixPizzaEdit">Prix de la pizza</label>
                <input id="PrixPizzaEdit" type="text" name="NewPrixPizza" placeholder="10" class="inputAddmodalPizza">
            </div>
            
            
            <div class="formContent btndiv">
                <input type="submit" value="Modifier" class="inputAddmodalPizza btn"> 
            </div>       
            
            <?php echo csrf_field(); ?>
        </form>
    
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Bureau\test\TM4\resources\views/admin/dashboard/pizza.blade.php ENDPATH**/ ?>