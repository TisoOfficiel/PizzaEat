

<?php $__env->startSection('title','Dashboard'); ?>

<?php $__env->startSection('linkCSS','/css/dashboard.css'); ?>

<?php $__env->startSection('content'); ?>

<!-- Menu nav bar horizontal -->
<div class="menuContainer">
    <!-- Menu de navigation horizontal -->
    <div>
        <i id="menuicon" class="material-icons" onclick="openNav()"> menu</i>
    </div>

    <!-- Logo -->
    <div>
        <a href="/"><img src="/img/logo_pizza1.png" class="logo"></a>
    </div>
    
   <!-- affichafe personne connecter -->

    <div id="infoUser" class="infoUser" onclick="dropdownmenu()">
       <p><?php echo e(Auth::user()->prenom); ?></p>
       <i class="material-icons">expand_more</i>
        <div id="infoUserDropdown" class="infoUserDropdown">
            <div class="infoUserDropdownTitle">
                <p class="infoUserDropdownAuthTitle">Enregistrer comme</p>
                <p class="infoUserDropdownAuth"><?php echo e(Auth::user()-> nom); ?> <?php echo e(Auth::user()-> prenom); ?></p>
            </div>

           <div class="infoUserDropdownContent">
                <a href="/">
                    <div class="infoUserDropdownAccueil">
                        <i class="material-icons">home</i>
                        <p>Accueil</p>
                    </div>
                </a>

                <a href="">
                    <div class="infoUserDropdownModifierProfile">
                        <i class="material-icons">edit</i>
                        <p>Modifier son profile</p>
                    </div>
                </a>
           </div>

            <a href="<?php echo e(route('logout')); ?>">
                <div class="infoUserDropdownLogout">
                    <i class="material-icons">logout</i>
                    <p>Se déconnecter</p>
                </div>
            </a>
        </div>
   </div>

</div>



<div class="containersidebar" id ="containersidebar">
    <div id="mySidenav" class="sidenav">
        
        <i class="material-icons" id="closenav" onclick="closeNav()">close</i>

        <div class="profileContainer">
            <div class="profileIcone">
            <i id="personneIcon"class="material-icons">person</i>
        </div>
            
            <div class="profileInfo">
                <p>
                    <?php echo e(Auth::user()->prenom); ?>

                    <?php if(Auth::user()->type=='admin'): ?>
                        <i id="adminIcon" class="material-icons">verified</i>
                    <?php endif; ?>
                </p>
                <a href="#">Voir le compte</a>
            </div>
        </div>
                    
        <?php if(Auth::user()->type=='admin'): ?>
            <div class="sidenavdashboard">
                <i class="material-icons">dashboard</i>
                <a href="<?php echo e(route('dashboard')); ?>" class="sidenavlist">Dashboard</a>
            </div>
        <?php endif; ?>
        <div class="sidenavCommande">
            <i class="material-icons">bookmark</i>
            <a href="#" class="sidenavlist">Commandes</a>
        </div>

        <div class="sidenavChangementCompte">
            <i class="material-icons">switch_account</i>
            <a href="#"class="sidenavlist">Changer de compte</a>
        </div>  

        <div class="sidenavdeconnexion">
            <i class="material-icons">logout</i>   
            <a href="<?php echo e(route('logout')); ?>"class="sidenavlist">Déconnexion</a>
        </div>
    </div>
</div>

<div>

</div>

<div class="dashboardContainer">
    <div class="dashboardMenu">
        
        <button class="tablinks" onclick="openCity(event, 'London')" ><i class="material-icons">dashboard</i>Dashboard</button>
        <button class="tablinks" onclick="openCity(event, 'Paris')">Commande</button>
        <button class="tablinks" onclick="openCity(event, 'Tokyo')" id="defaultOpen" >Pizza</button>
        <button id="utilisateur"class="tablinks" onclick="openCity(event, 'NY')">Utilisateur</button>
        
    </div>

    <div class="dashboardContent">

        <div id="London" class="tabcontent">
                
                <!-- HEADER -->
                <h1><span class="handIcon">👋</span>Bonjour, <?php echo e(Auth::user()->prenom); ?> !</h1>
                <div class="separation"></div>
                
                <!-- Les widget top -->
                <div class="widgetTop">
                    <div class="recette">
                        <div class="recetteContent">
                            <p class="recetteTitle">Recette du jour</p>
                            <p class="recetteValue"><?php echo e($usercount); ?></p>
                        </div>
                        <div class="recetteIconContainer">
                            <i class="material-icons iconrecette">credit_card</i>
                        </div>
                    </div>


                    <div class="nbUser">
                        <div class="nbUserContent">
                            <p class="nbUserTitle">Total d'utilisateurs</p>
                            <p class="nbUserNumber"><?php echo e($usercount); ?></p>
                        </div>
                        <div class="nbUserIconContainer">
                            <i class="material-icons iconNbUser">group</i>
                        </div>
                    </div>

                    <div class="nbCommande">
                        <div class="nbCommandeContent">
                            <p class="nbCommandeTitle">Total de commandes</p>
                            <p class="nbCommandeValue"><?php echo e($usercount); ?></p>
                        </div>
                        <div class="nbCommandeIconContainer">
                            <i class="material-icons iconNbCommande">local_shipping</i>
                        </div>
                    </div>

                    <div class="nbPizza">
                        <div class="pizzaContent">
                            <p class="pizzaTitle">Total pizzas</p>
                            <p class="pizzaNumber"><?php echo e($countpizzas); ?></p>
                        </div>
                        <div class="pizzaIconContainer">
                            <i class="material-icons iconPizza">local_pizza</i>
                        </div>
                    </div>
                </div>

                <!-- Widget body -->
                <div class="widgetBody">
                    <div class="tableCommandeContainer">
                            <!-- Si pas de commande  -->
                            <div class="NoCommandeContainer">
                                <p>Aucune commande effectuer.</p>        
                            </div>
                            <table class="tableCommandeContent">
                                <div class="tableCommandeHeader">
                                    <p class="tableCommandeTitle">Commande récentes</p>
                                    <p class="tableCommandePagination">PREVIEW NEXT</p>
                                </div>
                               
                                <!-- Table Header -->
                                <!-- <th class="tableCommandeHeader">IDC</th>
                                <th class="tableCommandeHeader">NOM PRENOM</th>
                                
                                <th class="tableCommandeHeader">IDC</th>
                                <th class="tableCommandeHeader">Statue</th>
                                <th class="tableCommandeHeader">Date</th>
                                <th class="tableCommandeHeader">PRIX</th> -->
                                
                                <!-- Table Content -->   
                                <?php for($i = 1; $i < 8; $i++): ?>
                                    <tr class="tableCommandeligne">
                                        <td class="Text-Start">??</td>
                                        <td>Null</td>
                                        <td>Null</td>
                                        <td>Null</td>
                                        <td>Null</td>
                                        <td>
                                            <a href="" class="tableCommandeDetail">Detail</a>
                                        </td>
                                    </tr>
                                <?php endfor; ?>
                            </table>
                        <!-- $quelquechose->links('pagination.pagination-link') -->
                    </div>

                    <div class="recentUserContainer">
                        <div class="recentUserHeader">
                            <p class="recentUserTitle">Utilisateurs récents</p>
                            <p class="recentUserlink" onclick="voirplusUser()">Voir tout</p>
                        </div>
                        <?php $__currentLoopData = $usersrecent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="recentUserContent">
                            <div class="userIconProfile">
                                <i class="material-icons recentIconUser">person</i>
                            </div>

                            <div class="UserProfileContent">
                                <p class="recentUserInfo"><?php echo e($user->nom); ?> <?php echo e($user->prenom); ?></p>
                                
                                <?php if($user->type == 'admin'): ?>
                                <p class="recentUserRoleAdmin"><?php echo e($user->type); ?></p>
                                @elif($user->type=='cook')
                                <p class="recentUserRoleCook"><?php echo e($user->type); ?></p>
                                <?php else: ?>
                                <p class="recentUserRoleUser"><?php echo e($user->type); ?></p>
                                <?php endif; ?>
                            </div>
                            <a href="#">
                            <div class="userIconMoreInfo">
                                <i class="material-icons">more_vert</i>
                            </div></a>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!--<table class="tableUserContent">
                            <th class="tableUserHeader">ID</th>
                            <th class="tableUserHeader">Nom</th>
                            <th class="tableUserHeader">Prénom</th>
                            <th class="tableUserHeader">Role</th>
                            <?php $__currentLoopData = $usersrecent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="tableUserligne">
                                    <td>$user->id</td>
                                    <td>$user->nom</td>
                                    <td>$user->prenom</td>
                                    <td>$user->type</td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                         -->
                    </div>
                </div>
                
        </div>

        <div id="Paris" class="tabcontent">
            <h3>Paris</h3>
            <p>Paris is the capital of France.</p> 
        </div>

        

        <div id="NY" class="tabcontent">
            <h3>New York</h3>
            <p>New is the capital of USA.</p>
        </div>
    </div>
</div>

<script>
    function voirplusUser(){
        
       
        tabcontent = document.getElementsByClassName("tabcontent");
        for (i = 0; i < tabcontent.length; i++) {
            tabcontent[i].style.display = "none";
        }
        document.getElementById('NY').style.display = "block";
        tablinks = document.getElementsByClassName("tablinks");
        for (i = 0; i < tablinks.length; i++) {
            tablinks[i].className = tablinks[i].className.replace(" active", "");
        }
        document.getElementById('utilisateur').className += " active";
    }

    function openCity(evt, cityName) {
        var i, tabcontent, tablinks;
        tabcontent = document.getElementsByClassName("tabcontent");
        for (i = 0; i < tabcontent.length; i++) {
            tabcontent[i].style.display = "none";
        }
        tablinks = document.getElementsByClassName("tablinks");
        for (i = 0; i < tablinks.length; i++) {
            tablinks[i].className = tablinks[i].className.replace(" active", "");
        }
        document.getElementById(cityName).style.display = "block";
        evt.currentTarget.className += " active";
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();
</script>

<script>
    function dropdownmenu(){
        document.getElementById("infoUserDropdown").style.display = "flex";
    };
    var ignoreClickOnMeElement = document.getElementById('infoUser');
    var ignoreClickOnMeElement1 =document.getElementById('infoUserDropdown');
    document.addEventListener('click', function(event) {
        var isClickInsideElement = ignoreClickOnMeElement.contains(event.target);
        var isClickInsideElement1 = ignoreClickOnMeElement1.contains(event.target);
        if (!isClickInsideElement && !isClickInsideElement1 ) {
            //Do something click is outside specified element
            document.getElementById("infoUserDropdown").style.display = "none";
        }
    });
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Bureau\test\TM4\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>