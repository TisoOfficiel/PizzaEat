

<?php $__env->startSection('title','Carte- PIZZA'); ?>
<?php $__env->startSection('linkCSS','/css/menu_nav_bar.css'); ?>
<?php $__env->startSection('linkCSS1','/css/content_Container.css'); ?>
<?php $__env->startSection('linkCSS2','/css/panier.css'); ?>
<?php $__env->startSection('linkCSS3','/css/menu_vertical.css'); ?>
<?php $__env->startSection('content'); ?>

<div class="menuContainer">


    <div>
        <i id="menuicon" class="material-icons" onclick="openNav()"> menu</i>
    </div>

    <!-- Logo -->
    <div>
        <a href="/"><img src="/img/logo_pizza1.png" class="logo"></a>
    </div>
    
    

    <!-- bar de recherche -->
    <div class="seach_bar">
        <i class="material-icons seachicon">search</i>
        <input type="text" placeholder="4 Fromages ..." class="seach_bar_input">
    </div>
       
    <!-- Panier -->
    <div class="panierdiv" onclick="openPanier()">
        <i id="shoplogo" class="material-icons">shopping_cart</i>
        <?php $totalquantite = 0 ?>
        <?php if(session('panier')): ?>
            <?php $__currentLoopData = session('panier'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pizza): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>           
                <?php $totalquantite += $pizza['quantite'] ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <p>Panier - <?php echo e($totalquantite); ?></p>
        <?php else: ?>
            <p>Panier - 0</p>
        <?php endif; ?>     
    </div>

    <div id="panierContainer" class="panierContainer">
        
        <?php if(session('panier')): ?>
       
        <div class="ItemShoppingCart"> 

            <div class="closeShoppingCart"  onclick="closePanier()">
                <i class="material-icons closeShoppingCartIcon">close</i>
            </div>
            <?php $total = 0 ?>
            <div class="ItemShoppingCartContainers">
               
                    <div class="ItemShoppingCartContent">
                       <ul>
            
                        <?php $__currentLoopData = session('panier'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pizza): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <?php $total += $pizza['prix'] * $pizza['quantite'] ?>
                           
                               
                            <?php if($pizza['quantite']>0): ?>
                                <li class="lv lu lt">
                                    <div class="selectContainer">
                                        <div class="selectContent">
                                        
                                            <form action="<?php echo e(route('panier_add',['id'=>$pizza['id']])); ?>" method="post">
                                                
                                                <select name="selectquantite" class="select" onchange="this.form.submit()">
                                                    <option value="0">supprimer</option>
                                                
                                                    <?php for($i = 1; $i < 99; $i++): ?>
                                                        <?php if($i==$pizza['quantite']): ?>
                                                            <option value="$pizza['quantite']" selected ><?php echo e($pizza['quantite']); ?></option>

                                                        <?php else: ?>
                                                            <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                                        <?php endif; ?>
                                                    <?php endfor; ?>
                                                </select>
                                                <?php echo csrf_field(); ?>
                                            </form>
                                            <div class="arrowSelectContainer">
                                                <div  class="arrowSelectContent">
                                                    <i class="material-icons">expand_more</i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="ItemShoppingCartInfo">
                                        <div class="ItemInfo">
                                            <?php echo e($pizza['nom']); ?>

                                        </div>
                                        
                                        <div class="ItemPrix">
                                            
                                            <?php echo e($pizza['prix'] * $pizza['quantite']); ?> €
                                        </div>
                                        
                                    </div>
                                    
                                </li>
                                
                            <?php endif; ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>   
                    </div>
                    
                    <div class="r9"></div>
                    <div class="submiCommandebtn">
                        <a href="<?php echo e(route('checkout')); ?>">Commander - <?php echo e($total); ?> €</a>
                    </div>
            </div>
        </div>
        <?php else: ?>
        <div class="noItemShoppingCart">
            <div class="closeShoppingCart" onclick="closePanier()">
                <i class="material-icons closeShoppingCartIcon">close</i>
            </div>
            <div class="noItemShoppingCartContainer">
                <i class="material-icons shoppingCartIcon">shopping_cart</i>
                <p>Ajoutez des articles pour commencer un nouveau panier.</p>
            </div>
        </div>
        <?php endif; ?>
        
    </div>

    <!-- Affichage pour du lien se connecter pour les personnes non connecter -->
    <?php if(auth()->guard()->guest()): ?>
    <div class="signIn">
        <a href="<?php echo e(route('login')); ?>">Se connecter</a>
    </div>
    <?php endif; ?>
    
</div>

<div class="contentContainer">

    <div class="filtre">
        <label for="TopVente"><input type="checkbox" name="" id="TopVente" >Top vente</label>
    </div>
<!-- Pizza -->
    <div class="bodyContainer">


        <?php $__empty_1 = true; $__currentLoopData = $pizzas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pizza): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php if($loop->first): ?>

                <div class="pizzaContainer">
                
                    <?php endif; ?>
                
                    <div class="pizzaContent">
                        <div class="PizzaINFORMATION">

                            <h6><?php echo e($pizza->nom); ?></h6>
                            <h4><?php echo e($pizza->prix); ?> €</h4>
                        </div>
                        <img src="storage\img_pizza\<?php echo e($pizza->id); ?>.png" alt="">
                        <div class="iconaddContainer" >
                    
                            <form action="<?php echo e(route('panier_add',['id'=>$pizza->id])); ?>" method="post">
                                <?php echo csrf_field(); ?>

                                <?php if(session('panier')): ?>
                                    <?php $__currentLoopData = session('panier'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pizzapanier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if( $pizzapanier['id'] == $pizza->id): ?>    
                                            <?php if($pizzapanier['quantite']>1): ?>
                                            <button class="removeshoppingCartButton" type="submit" name="statue" value="remove" onclick="this.form.submit()"><i class="material-icons" >remove</i></button>

                                            <?php else: ?>
                                            <button class="removeshoppingCartButton" type="submit" name="statue" data_value ="false" value="remove" onclick="this.form.submit()"><i class="material-icons" >delete</i></button>

                                            <?php endif; ?>
                                            
                                            <p class="numberquantite"><?php echo e($pizzapanier['quantite']); ?></p>
                                        <?php endif; ?>
                                    
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>

                                <button class="addshoppingCartButton" type="submit" name="statue" value="add" onclick="this.form.submit()"><i class="material-icons" >add</i></button>
                                
                            </form>
                            
                        </div>
                    </div>

            <?php if($loop->last): ?>
                </div>
            
            <?php endif; ?>
            

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                <p>Désolé... toutes nos pizzas sont en rupture de stock repasser plus tards.</p>

        <?php endif; ?>
    
        <div class="testpaginate">
            <?php echo e($pizzas->links('pagination.pagination-linkPizza')); ?>

        </div>
    </div>
</div>
       

    <div class="containersidebar" id ="containersidebar">
        <?php if(auth()->guard()->guest()): ?>
        <div id="mySidenav" class="sidenavguest">
            <i class="material-icons" id="closenav" onclick="closeNav()">close</i>
            <a href="<?php echo e(route('login')); ?>" class="loginLink">
                <div class="loginContainer">
                    Se connecter
                </div>
            </a>
            <div class="registerContainer">
                <a href="<?php echo e(route('registerForm')); ?>">Créez un compte</a>
            </div>
                
        <?php endif; ?>


        <?php if(auth()->guard()->check()): ?>
            <div id="mySidenav" class="sidenav">
                <i class="material-icons" id="closenav" onclick="closeNav()">close</i>

                <div class="profileContainer">
                    <div class="profileIcone">
                        <i id="personneIcon"class="material-icons">person</i>
                    </div>
                    <div class="profileInfo">
                        <p>
                            <?php echo e(Auth::user()->prenom); ?>

                            <?php if(Auth::user()->type=='admin'): ?>
                                    <i id="adminIcon" class="material-icons">verified</i>
                            <?php endif; ?>
                            <?php if(Auth::user()->type=='cook'): ?>
                                    <i id="adminIcon" class="material-icons">soup_kitchen</i>
                            <?php endif; ?>
                        </p>
                        <a href="/<?php echo e(Auth::user()->id); ?>/compteSetting">Voir le compte</a>
                    </div>

                
                </div>
                
                <?php if(Auth::user()->type=='admin'): ?>
                <div class="sidenavdashboard">
                    <i class="material-icons">dashboard</i>
                    <a href="<?php echo e(route('dashboard')); ?>" class="sidenavlist">Dashboard</a>
                </div>
                <?php endif; ?>

                <?php if(Auth::user()->type=='cook'): ?>
                <div class="sidenavdashboard">
                    <i class="material-icons">dashboard</i>
                    <a href="<?php echo e(route('CookDashboard')); ?>" class="sidenavlist">Dashboard</a>
                </div>
                <?php endif; ?>
                <div class="sidenavCommande">
                    <i class="material-icons">bookmark</i>
                    <a href="<?php echo e(route('commandeView',['id'=>Auth::user()->id])); ?>" class="sidenavlist">Commandes</a>
                </div>

                <div class="sidenavChangementCompte">
                    <i class="material-icons">switch_account</i>
                    <a href="#"class="sidenavlist">Changer de compte</a>
                </div>  

                <div class="sidenavdeconnexion">
                    <i class="material-icons">logout</i>   
                    <a href="<?php echo e(route('logout')); ?>"class="sidenavlist">Déconnexion</a>
                </div>
        <?php endif; ?>             
                
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Bureau\test\TM4\resources\views/index.blade.php ENDPATH**/ ?>