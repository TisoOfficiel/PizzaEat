<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="<?php echo $__env->yieldContent('linkCSS'); ?>">    
    <link rel="stylesheet" href="<?php echo $__env->yieldContent('linkCSS1'); ?>">    
    <link rel="stylesheet" href="<?php echo $__env->yieldContent('linkCSS2'); ?>"> 
    <link rel="stylesheet" href="<?php echo $__env->yieldContent('linkCSS3'); ?>"> 
       

    <!-- Link pour les icons -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    
    <!-- Link pour la font  -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap" rel="stylesheet">

    <style>
        body{
            margin: 0;
            padding: 0;
            font-family: 'Roboto', sans-serif;
            background-color:#fbf5ee;
        }
    </style>
    <!-- Bootsrap -->

    
    <?php echo $__env->yieldContent('style'); ?>
</head>
<body>
    
    <?php echo $__env->yieldContent('content'); ?>
    <script type="text/javascript" src="<?php echo e(URL::asset('/js/app.js')); ?>"></script>
    
</body>
</html>


<?php /**PATH D:\Bureau\test\TM4\resources\views/layout/app.blade.php ENDPATH**/ ?>