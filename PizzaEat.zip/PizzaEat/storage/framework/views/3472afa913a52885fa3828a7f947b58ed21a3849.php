

<?php $__env->startSection('content'); ?>

    <p>Hello World</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Bureau\test\TM4\resources\views/user/commande.blade.php ENDPATH**/ ?>