<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

        <p>Page d' accueil.</p>
        
        <?php if(auth()->guard()->check()): ?>
        <p>Bonjour <?php echo e(Auth::user()->nom); ?> <?php echo e(Auth::user()->prenom); ?></p>
        <div><a href="<?php echo e(route('logout')); ?>">Se deconnecter</></div>

        <div><a href="<?php echo e(route('mdp_changer_form')); ?>">Mot de passe oublié</a></div>
       
        <?php endif; ?>

</body>
</html><?php /**PATH D:\Bureau\test\TM4\resources\views/home.blade.php ENDPATH**/ ?>