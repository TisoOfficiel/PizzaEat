

<?php $__env->startSection('title','Connextion'); ?>

<?php $__env->startSection('linkCSS','/css/login_register/register.css'); ?>

<?php $__env->startSection('content'); ?>

<section>

    <div class="formContainer">
        <h1>S'enregistrer</h1>
        <!-- Formulaire d'enregistrement -->
        <form action="<?php echo e(route('register')); ?>" method="post">
                
            <div class="formContent">
               
                <input id="login" type="text" name="login" value="<?php echo e(old('login')); ?>" placeholder="Login">
            </div>
            
            <div class="formContentInfo">
               
                <input id="nom" type="text" name="nom"value="<?php echo e(old('nom')); ?>" placeholder="Nom">
                <input id="prenom" type="text" name="prenom" value="<?php echo e(old('prenom')); ?>" placeholder="Prénom">
                
            </div>
                
            <div class="formContent mdp">
               
                <input type="password" name="mdp" id="mdpRegister" placeholder="Mot de passe">
                <i id="passwordNotVisble"class="material-icons passwordNotVisble" onclick="visiblemdpregister()">visibility_off</i>
            </div>

            <div class="formContent mdp">
                <input type="password" name="mdp_confirmation" id="mdpRegisterConfirmation" placeholder="Confirmation de mot de passe">
                
            </div>    
                
            
            <div class="formContentSubmit">
                <input type="submit" value="S'enregistrer" class="btn">
            </div>
            <?php echo csrf_field(); ?>
        </form>
        <div class="pasCompte">
            <p>Déja un compte ? <a href="<?php echo e(route('login')); ?>">Se connecter</a></p>
        </div>
        
        <div class="otherConnexion">
            <a href="#">
                <div class="Google">
                    <img src="https://img.icons8.com/color/24/000000/google-logo.png"/>
                    <p>Google</p>
                </div>
            </a>
            <a href="#">
                <div class="Facebook">
                <img src="https://img.icons8.com/fluency/24/000000/facebook.png"/>
                    <p>Facebook</p>
                </div>
            </a>
        

        </div>
        

    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Bureau\test\TM4\resources\views/auth/register.blade.php ENDPATH**/ ?>