

<?php $__env->startSection('content'); ?>
      

    <img src="storage\img_pizzatest\f_.png" alt="">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Bureau\test\TM4\resources\views/test.blade.php ENDPATH**/ ?>