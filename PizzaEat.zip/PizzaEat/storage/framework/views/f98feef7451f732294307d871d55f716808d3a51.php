<?php if($paginator->hasPages()): ?>
    <ul class="flex justify-between">
        <li >Prev</li>
        <li >Next<li>
    </ul>
<?php endif; ?><?php /**PATH D:\Bureau\test\TM4\resources\views/pagination-link.blade.php ENDPATH**/ ?>