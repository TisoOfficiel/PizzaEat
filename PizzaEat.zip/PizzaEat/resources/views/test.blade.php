@extends('layout.app')

@section('content')
      

    <img src="storage\img_pizzatest\{{pizza->id}}.png" alt="">
@endsection